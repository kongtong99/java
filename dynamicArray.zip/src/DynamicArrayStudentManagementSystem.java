import java.util.Scanner;

class Student {
    String studentId;
    String name;
    int age;
    String gender;
    String idCard;
    String phone;

    public Student(String studentId, String name, int age, String gender, String idCard, String phone) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.idCard = idCard;
        this.phone = phone;
    }
}

public class DynamicArrayStudentManagementSystem {
    private Student[] students;
    private int size;
    private Scanner scanner = new Scanner(System.in);

    public DynamicArrayStudentManagementSystem() {
        students = new Student[10]; // 初始容量为10
        size = 0;
    }

    public static void main(String[] args) {
        DynamicArrayStudentManagementSystem system = new DynamicArrayStudentManagementSystem();
        system.run();
    }

    public void run() {
        while (true) {
            System.out.println("学生管理系统");
            System.out.println("1.添加学生信息");
            System.out.println("2.修改学生信息");
            System.out.println("3.删除学生信息");
            System.out.println("4.查看学生信息");
            System.out.println("5.查看所有学生信息");
            System.out.println("0.退出系统");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    updateStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    viewStudent();
                    break;
                case 5:
                    viewAllStudents();
                    break;
                case 0:
                    System.out.println("感谢使用学生管理系统，再见！");
                    System.exit(0);
                    break;
                default:
                    System.out.println("无效的选择，请重新输入");
            }
        }
    }

    private void addStudent() {
        System.out.println("请输入学号:");
        String studentId = scanner.nextLine();

        // 检查学号是否重复
        for (int i = 0; i < size; i++) {
            if (students[i].studentId.equals(studentId)) {
                System.out.println("学号重复，添加失败！");
                return;
            }
        }

        System.out.println("请输入姓名:");
        String name = scanner.nextLine();
        System.out.println("请输入年龄:");
        int age = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.println("请输入性别:");
        String gender = scanner.nextLine();
        System.out.println("请输入身份证号:");
        String idCard = scanner.nextLine();
        System.out.println("请输入电话号码:");
        String phone = scanner.nextLine();

        // 如果数组容量不够，扩展数组
        if (size == students.length) {
            expandArray();
        }

        Student newStudent = new Student(studentId, name, age, gender, idCard, phone);
        students[size] = newStudent;
        size++;
        System.out.println("学生信息添加成功！");
    }

    private void updateStudent() {
        System.out.println("请输入要修改的学生的学号:");
        String studentId = scanner.nextLine();

        for (int i = 0; i < size; i++) {
            if (students[i].studentId.equals(studentId)) {
                System.out.println("请输入新的姓名:");
                students[i].name = scanner.nextLine();
                System.out.println("请输入新的年龄:");
                students[i].age = scanner.nextInt();
                scanner.nextLine(); // consume newline
                System.out.println("请输入新的性别:");
                students[i].gender = scanner.nextLine();
                System.out.println("请输入新的身份证号:");
                students[i].idCard = scanner.nextLine();
                System.out.println("请输入新的电话号码:");
                students[i].phone = scanner.nextLine();
                System.out.println("学生信息修改成功！");
                return;
            }
        }

        System.out.println("找不到该学生，修改失败！");
    }

    private void deleteStudent() {
        System.out.println("请输入要删除的学生的学号:");
        String studentId = scanner.nextLine();

        for (int i = 0; i < size; i++) {
            if (students[i].studentId.equals(studentId)) {
                // 将删除位置后面的元素向前移动
                for (int j = i; j < size - 1; j++) {
                    students[j] = students[j + 1];
                }
                size--;
                System.out.println("学生信息删除成功！");
                return;
            }
        }

        System.out.println("找不到该学生，删除失败！");
    }

    private void viewStudent() {
        System.out.println("请输入要查询的学生的学号:");
        String studentId = scanner.nextLine();

        for (int i = 0; i < size; i++) {
            if (students[i].studentId.equals(studentId)) {
                printStudentDetails(students[i]);
                return;
            }
        }

        System.out.println("找不到该学生，查询失败！");
    }

    private void viewAllStudents() {
        if (size == 0) {
            System.out.println("系统中没有学生信息！");
        } else {
            System.out.println("所有学生信息如下:");
            for (int i = 0; i < size; i++) {
                printStudentDetails(students[i]);
            }
        }
    }

    private void printStudentDetails(Student student) {
        System.out.println("学号: " + student.studentId);
        System.out.println("姓名: " + student.name);
        System.out.println("年龄: " + student.age);
        System.out.println("性别: " + student.gender);
        System.out.println("身份证号: " + student.idCard);
        System.out.println("电话号码: " + student.phone);
        System.out.println();
    }

    private void expandArray() {
        // 扩展数组容量为原来的两倍
        Student[] newArray = new Student[students.length * 2];
        System.arraycopy(students, 0, newArray, 0, students.length);
        students = newArray;
    }
}
