import java.sql.*;
import java.util.Scanner;

public class StudentDatabaseManagementSystem {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/student_database";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "123456";

    public static void main(String[] args) {
        try {
            // 注册JDBC驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 连接数据库
            Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

            // 创建表（如果不存在）
            createTable(connection);

            // 运行学生管理系统
            runStudentManagementSystem(connection);

            // 关闭连接
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createTable(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("CREATE DATABASE IF NOT EXISTS student_database");
            statement.executeUpdate("USE student_database");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS students (" +
                    "student_id VARCHAR(10) PRIMARY KEY," +
                    "name VARCHAR(100)," +
                    "age INT," +
                    "gender VARCHAR(10)," +
                    "id_card VARCHAR(20)," +
                    "phone VARCHAR(15)" +
                    ")");
        }
    }

    private static void runStudentManagementSystem(Connection connection) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("学生管理系统");
            System.out.println("1.添加学生信息");
            System.out.println("2.修改学生信息");
            System.out.println("3.删除学生信息");
            System.out.println("4.查看学生信息");
            System.out.println("5.查看所有学生信息");
            System.out.println("0.退出系统");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    addStudent(connection);
                    break;
                case 2:
                    updateStudent(connection);
                    break;
                case 3:
                    deleteStudent(connection);
                    break;
                case 4:
                    viewStudent(connection);
                    break;
                case 5:
                    viewAllStudents(connection);
                    break;
                case 0:
                    System.out.println("感谢使用学生管理系统，再见！");
                    System.exit(0);
                    break;
                default:
                    System.out.println("无效的选择，请重新输入");
            }
        }
    }

    private static void addStudent(Connection connection) {
        try {
            Scanner scanner = new Scanner(System.in);

            System.out.println("请输入学号:");
            String studentId = scanner.nextLine();

            // 检查学号是否重复
            if (isStudentIdExists(connection, studentId)) {
                System.out.println("学号重复，添加失败！");
                return;
            }

            System.out.println("请输入姓名:");
            String name = scanner.nextLine();
            System.out.println("请输入年龄:");
            int age = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.println("请输入性别:");
            String gender = scanner.nextLine();
            System.out.println("请输入身份证号:");
            String idCard = scanner.nextLine();
            System.out.println("请输入电话号码:");
            String phone = scanner.nextLine();

            // 执行插入操作
            try (PreparedStatement preparedStatement = connection.prepareStatement(
                    "INSERT INTO students VALUES (?, ?, ?, ?, ?, ?)")) {
                preparedStatement.setString(1, studentId);
                preparedStatement.setString(2, name);
                preparedStatement.setInt(3, age);
                preparedStatement.setString(4, gender);
                preparedStatement.setString(5, idCard);
                preparedStatement.setString(6, phone);

                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("学生信息添加成功！");
                } else {
                    System.out.println("学生信息添加失败！");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateStudent(Connection connection) {
        try {
            Scanner scanner = new Scanner(System.in);

            System.out.println("请输入要修改的学生的学号:");
            String studentId = scanner.nextLine();

            // 检查学号是否存在
            if (!isStudentIdExists(connection, studentId)) {
                System.out.println("找不到该学生，修改失败！");
                return;
            }

            System.out.println("请输入新的姓名:");
            String name = scanner.nextLine();
            System.out.println("请输入新的年龄:");
            int age = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.println("请输入新的性别:");
            String gender = scanner.nextLine();
            System.out.println("请输入新的身份证号:");
            String idCard = scanner.nextLine();
            System.out.println("请输入新的电话号码:");
            String phone = scanner.nextLine();

            // 执行更新操作
            try (PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE students SET name=?, age=?, gender=?, id_card=?, phone=? WHERE student_id=?")) {
                preparedStatement.setString(1, name);
                preparedStatement.setInt(2, age);
                preparedStatement.setString(3, gender);
                preparedStatement.setString(4, idCard);
                preparedStatement.setString(5, phone);
                preparedStatement.setString(6, studentId);

                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("学生信息修改成功！");
                } else {
                    System.out.println("学生信息修改失败！");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteStudent(Connection connection) {
        try {
            Scanner scanner = new Scanner(System.in);

            System.out.println("请输入要删除的学生的学号:");
            String studentId = scanner.nextLine();

            // 检查学号是否存在
            if (!isStudentIdExists(connection, studentId)) {
                System.out.println("找不到该学生，删除失败！");
                return;
            }

            // 执行删除操作
            try (PreparedStatement preparedStatement = connection.prepareStatement(
                    "DELETE FROM students WHERE student_id=?")) {
                preparedStatement.setString(1, studentId);

                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("学生信息删除成功！");
                } else {
                    System.out.println("学生信息删除失败！");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewStudent(Connection connection) {
        try {
            Scanner scanner = new Scanner(System.in);

            System.out.println("请输入要查询的学生的学号:");
            String studentId = scanner.nextLine();

            // 查询学生信息
            try (PreparedStatement preparedStatement = connection.prepareStatement(
                    "SELECT * FROM students WHERE student_id=?")) {
                preparedStatement.setString(1, studentId);

                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    printStudentDetails(resultSet);
                } else {
                    System.out.println("找不到该学生，查询失败！");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllStudents(Connection connection) {
        try {
            // 查询所有学生信息
            try (Statement statement = connection.createStatement()) {
                ResultSet resultSet = statement.executeQuery("SELECT * FROM students");
                if (resultSet.next()) {
                    do {
                        printStudentDetails(resultSet);
                    } while (resultSet.next());
                } else {
                    System.out.println("系统中没有学生信息！");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static boolean isStudentIdExists(Connection connection, String studentId) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement(
                "SELECT * FROM students WHERE student_id=?")) {
            preparedStatement.setString(1, studentId);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        }
    }

    private static void printStudentDetails(ResultSet resultSet) throws SQLException {
        System.out.println("学号: " + resultSet.getString("student_id"));
        System.out.println("姓名: " + resultSet.getString("name"));
        System.out.println("年龄: " + resultSet.getInt("age"));
        System.out.println("性别: " + resultSet.getString("gender"));
        System.out.println("身份证号: " + resultSet.getString("id_card"));
        System.out.println("电话号码: " + resultSet.getString("phone"));
        System.out.println();
    }
}
