CREATE DATABASE IF NOT EXISTS student_database;
USE student_database;

CREATE TABLE IF NOT EXISTS students (
                                        student_id VARCHAR(10) PRIMARY KEY,
                                        name VARCHAR(100),
                                        age INT,
                                        gender VARCHAR(10),
                                        id_card VARCHAR(20),
                                        phone VARCHAR(15)
);
